Revolver Readme
===============

About Revolver
--------------
Revolver allows you to create interesting 3D shapes without going
through all the hassle of vertex manipulation. If you've wanted to
create a rounded pipe corner or an intricate pillar, then the
solution is this program - all you have to do is draw a 2D profile.

Version Information
-------------------
This is the Beta 1 version of Revolver, build date 26th April '03.

Usage
-----
For information on how to use Revolver, see index.html in the
UserGuide directory. This contains a full and complete guide to
all the features of Revolver.

Found a bug?
------------
If you think you have found a bug in Revolver, send detailed
information (a saved file of the profile, parameters passed to the
revolve dialog if applicable) to deathwish@valve-erc.com.

Changelog
---------

Version Beta 1
- First release.

Contact
-------
If you have a suggestion for Revolver, send it to
deathwish@valve-erc.com or find me on IRC in the Valve-ERC channel
(irc.chatbear.com, #valveerc).

Copyright
---------
Revolver is Copyright (C) Francis "DeathWish" Woodhouse, 2003.