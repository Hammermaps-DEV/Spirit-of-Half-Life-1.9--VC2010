<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="generator" content="vBulletin 3.8.5">

<meta name="keywords" content="vbulletin,forum,bbs,svencoop,sven,coop,svenco-op,co-op,half-life,mods,mod,halflife,hl2,cooperative,co-operative,game,anime,manga,videogames,valve,software,modification,cs,retail,counterstrike,counter-strike,single-player,missions,maps">
<meta name="description" content="The Sven Co-op cooperative modification for the computer or video game Half-Life by Valve Software">


<!-- CSS Stylesheet -->
<style type="text/css" id="vbulletin_css">
/**
* vBulletin 3.8.5 CSS
* Style: 'Sven Co-op 3.5 - Larger text'; Style ID: 19
*/
body
{
	background: #000000;
	color: silver;
	font: 11pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	margin: 0px 0px 0px 0px;
	padding: 0px;
	background-image: url(images/bg_35.gif);
}
a:link, body_alink
{
	color: #E0E0F6;
	text-decoration: none;
}
a:visited, body_avisited
{
	color: #E0E0F6;
	text-decoration: none;
}
a:hover, a:active, body_ahover
{
	color: #FFFFFF;
	text-decoration: underline;
}
.page
{
	color: silver;
}
td, th, p, li
{
	color: white;
	font: 12px verdana, arial, helvetica;
}
.tborder
{
	background: #51586A;
	color: silver;
	border: 0px;
	background-image: url(images/gradients/bg_tab.gif);
}
.tcat
{
	background: #2B2F3C;
	color: #FFFFFF;
	font: bold 9pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	background-image: url(images/gradients/bg_cat.gif);
}
.tcat a:link, .tcat_alink
{
	color: #ffffff;
	text-decoration: none;
}
.tcat a:visited, .tcat_avisited
{
	color: #ffffff;
	text-decoration: none;
}
.tcat a:hover, .tcat a:active, .tcat_ahover
{
	color: #FFFFFF;
	text-decoration: underline;
}
.thead
{
	background: #252525;
	font: bold 12px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.thead a:link, .thead_alink
{
	color: #FFFFFF;
}
.thead a:visited, .thead_avisited
{
	color: #FFFFFF;
}
.thead a:hover, .thead a:active, .thead_ahover
{
	color: #FFFF00;
}
.tfoot
{
	color: #E0E0F6;
}
.tfoot a:link, .tfoot_alink
{
	color: #F0F0FF;
}
.tfoot a:visited, .tfoot_avisited
{
	color: #E0E0F6;
}
.tfoot a:hover, .tfoot a:active, .tfoot_ahover
{
	color: #FFFF66;
}
.alt1, .alt1Active
{
	background: #252834;
	color: silver;
}
.alt1 a:link, .alt1_alink, .alt1Active a:link, .alt1Active_alink
{
	color: #F0F0FF;
	text-decoration: none;
}
.alt1 a:visited, .alt1_avisited, .alt1Active a:visited, .alt1Active_avisited
{
	color: #E0E0F6;
	text-decoration: none;
}
.alt1 a:hover, .alt1 a:active, .alt1_ahover, .alt1Active a:hover, .alt1Active a:active, .alt1Active_ahover
{
	color: #FFFFFF;
	text-decoration: underline;
}
.alt2, .alt2Active
{
	background: #323645;
	color: silver;
}
.inlinemod
{
	background: #FFFFCC;
	color: #000000;
}
.wysiwyg
{
	background: #F5F5FF;
	color: #000000;
	font: 11pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	margin: 5px 10px 10px 10px;
	padding: 0px;
}
.wysiwyg a:link, .wysiwyg_alink
{
	color: #22229C;
}
.wysiwyg a:visited, .wysiwyg_avisited
{
	color: #22229C;
}
.wysiwyg a:hover, .wysiwyg a:active, .wysiwyg_ahover
{
	color: #FF4400;
}
textarea, .bginput
{
	font: 11pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.bginput option, .bginput optgroup
{
	font-size: 11pt;
	font-family: verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.button
{
	font: 12px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
select
{
	font: 12px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
option, optgroup
{
	font-size: 12px;
	font-family: verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.smallfont
{
	font: 9pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.time
{
	color: #EEEEEE;
}
.navbar
{
	font: 12px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.highlight
{
	color: white;
}
.fjsel
{
	background: #3E5C92;
	color: #E0E0F6;
}
.fjdpth0
{
	background: #F7F7F7;
	color: #000000;
}
.panel
{
	color: #CCCCFF;
}
.panelsurround
{
	background: #5A6376;
	color: #000000;
}
legend
{
	color: orange;
	font: 12px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.vbmenu_control
{
	background: #51586A;
	color: #FFFFFF;
	font: bold 12px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	padding: 3px 6px 3px 6px;
	white-space: nowrap;
}
.vbmenu_control a:link, .vbmenu_control_alink
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_control a:visited, .vbmenu_control_avisited
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_control a:hover, .vbmenu_control a:active, .vbmenu_control_ahover
{
	color: #FFFFFF;
	text-decoration: underline;
}
.vbmenu_popup
{
	background: #FFFFFF;
	color: #000000;
	border: 1px solid #0B198C;
}
.vbmenu_option
{
	background: #BBC7CE;
	color: #000000;
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	white-space: nowrap;
	cursor: pointer;
}
.vbmenu_option a:link, .vbmenu_option_alink
{
	color: #22229C;
	text-decoration: none;
}
.vbmenu_option a:visited, .vbmenu_option_avisited
{
	color: #22229C;
	text-decoration: none;
}
.vbmenu_option a:hover, .vbmenu_option a:active, .vbmenu_option_ahover
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_hilite
{
	background: #8A949E;
	color: #FFFFFF;
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	white-space: nowrap;
	cursor: pointer;
}
.vbmenu_hilite a:link, .vbmenu_hilite_alink
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_hilite a:visited, .vbmenu_hilite_avisited
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_hilite a:hover, .vbmenu_hilite a:active, .vbmenu_hilite_ahover
{
	color: #FFFFFF;
	text-decoration: none;
}
HTML, BODY{
scrollbar-base-color: #798399;
scrollbar-arrow-color: white;
}

SELECT 
{
	FONT-FAMILY: Verdana;
	FONT-SIZE: 10px;
	COLOR: #000000;
	BACKGROUND-COLOR: #CFCFCF
}

TEXTAREA, .bginput 
{
	FONT-SIZE: 11px;
	FONT-FAMILY: Verdana;
	COLOR: #000000;
	BACKGROUND-COLOR: #CFCFCF
}

A:link, A:visited, A:active {
	COLOR: {linkcolor}; TEXT-DECORATION: none;
}
A:hover {
	COLOR: {hovercolor}; TEXT-DECORATION: underline;
}
#cat A:link, #cat A:visited, #cat A:active {
	COLOR: {categoryfontcolor};
	TEXT-DECORATION: none;
}
#cat A:hover {
	COLOR: {categoryfontcolor};
	TEXT-DECORATION: underline;
}
#ltlink A:link, #ltlink A:visited, #ltlink A:active {
	COLOR: {linkcolor};
	TEXT-DECORATION: none;
}
#ltlink A:hover {
	COLOR: {hovercolor};
	TEXT-DECORATION: underline;
}
.thtcolor {
COLOR: silver;
}
.mytable { border: 1px #616889 solid; background-color: #3e3e3e; font-family: 
Verdana, Arial, Helvetica, sans-serif; font-size: 10px; color: silver;
text-decoration: none;}

.fontstuff
{
	FONT-SIZE: 12px;
	FONT-FAMILY: Verdana;
}

.fontstuffsmall
{
	FONT-SIZE: 11px;
}
</style>
<link rel="stylesheet" type="text/css" href="showpost-Dateien/vbulletin_important.css">


<!-- / CSS Stylesheet -->

<script type="text/javascript" src="showpost-Dateien/yahoo-dom-event.js"></script>
<script type="text/javascript" src="showpost-Dateien/connection-min.js"></script>
<script type="text/javascript">
<!--
var SESSIONURL = "";
var SECURITYTOKEN = "guest";
var IMGDIR_MISC = "images/misc";
var vb_disable_ajax = parseInt("0", 10);
// -->
</script>
<script type="text/javascript" src="showpost-Dateien/vbulletin_global.js"></script>
<script type="text/javascript" src="showpost-Dateien/vbulletin_menu.js"></script>


<title>Sven Co-op Message Forums - View Single Post -  custom version of ZHLT by vluzacn</title>
</head>
<body style="margin: 0px;" onload="self.focus()">

<form action="showpost.php">

<table class="tborder" style="border-bottom-width: 0px;" border="0" cellpadding="5" cellspacing="1" width="100%">
<tbody><tr>
	<td class="tcat">
		<div class="smallfont" style="float:right">
			<strong>Thread</strong>:  <a style="text-decoration: underline;" href="http://forums.svencoop.com/showthread.php?p=476471#post476471">custom version of ZHLT by vluzacn</a>
		</div>
		View Single Post
	</td>
</tr>
</tbody></table>



<!-- post #476471 -->



<table id="post476471" class="tborder" align="center" border="0" cellpadding="5" cellspacing="0" width="100%">
<tbody><tr>
	
		<td class="thead" style="font-weight: normal; border-width: 1px 0px 1px 1px; border-style: solid none solid solid; border-color: rgb(81, 88, 106) -moz-use-text-color rgb(81, 88, 106) rgb(81, 88, 106); -moz-border-top-colors: none; -moz-border-right-colors: none; -moz-border-bottom-colors: none; -moz-border-left-colors: none; -moz-border-image: none;" id="currentPost">
			<!-- status icon and date -->
			<a name="post476471"><img title="Old" class="inlineimg" src="showpost-Dateien/post_old.gif" alt="Old" border="0"></a>
			12-11-2011, 02:14 PM
			
			<!-- / status icon and date -->
		</td>
		<td class="thead" style="font-weight: normal; border-width: 1px 1px 1px 0px; border-style: solid solid solid none; border-color: rgb(81, 88, 106) rgb(81, 88, 106) rgb(81, 88, 106) -moz-use-text-color; -moz-border-top-colors: none; -moz-border-right-colors: none; -moz-border-bottom-colors: none; -moz-border-left-colors: none; -moz-border-image: none;" align="right">
			&nbsp;
			#<a href="http://forums.svencoop.com/showpost.php?p=476471&amp;postcount=368" target="new" rel="nofollow" id="postcount476471" name="368"><strong>368</strong></a>
			
		</td>
	
</tr>
<tr valign="top">
	<td class="alt2" style="border-right: 1px solid rgb(81, 88, 106); border-left: 1px solid rgb(81, 88, 106); -moz-border-top-colors: none; -moz-border-right-colors: none; -moz-border-bottom-colors: none; -moz-border-left-colors: none; -moz-border-image: none; border-width: 0px 1px; border-style: none solid; border-color: -moz-use-text-color rgb(81, 88, 106);" width="175">

			<div id="postmenu_476471">
				
				<a class="bigusername" href="http://forums.svencoop.com/member.php?u=12810">vluzacn</a>
				<script type="text/javascript"> vbmenu_register("postmenu_476471", true); </script>
				
			</div>

			<div class="smallfont">Registered User</div>
			
			
						
				
			
			
			 
			
			<div class="smallfont">
				&nbsp;<br>
				<div>Join Date: May 2010</div>
				<div>Location: China</div>
				
				<div>
					Posts: 166
				</div>
				
				
				
				
				<div>    </div>
			</div>

	</td>
	
	<td class="alt1" id="td_post_476471" style="border-right: 1px solid rgb(81, 88, 106);">
	
		
		
			<!-- icon and title -->
			<div class="smallfont">
				<img title="Default" class="inlineimg" src="showpost-Dateien/icon1.gif" alt="Default" border="0">
				<strong>Re: custom version of ZHLT by vluzacn</strong>
			</div>
			<hr style="color:#51586A; background-color:#51586A" size="1">
			<!-- / icon and title -->
		

		<!-- message -->
		<div id="post_message_476471">
			
			Update:<br>
<br>
version 25<br>
<br>
<br>
Improve hlrad's ability to handle the case of too many dynamic light styles on a face.<br>
When a face gets more than 3 different dynamic light styles, some of the
 light styles must be discarded. Now hlrad ensures that the brightest 3 
dynamic light styles will be kept.<br>
The 'too many styles' error will no longer occur. But any style darker 
than the 3 brightest styles will be discarded without any warnings, 
because I haven't created a warning for that.<br>
<br>
<br>
<br>
Add 'func_detail' entity, which is similar in function to the 
func_detail in Source, though I probably implement it in a rather 
different way.<br>
<br>
What is func_detail:<br>
 (Brushes that are not in any entities are called world brushes, and brushes in func_details are called detail brushes.)<br>
 Detail brushes are almost same to world brushes. They cannot be 
distinguished from world brushes once the compile has finished. For 
example, when viewing the bsp with 'BSP Viewer', func_details don't 
disappear after unchecking 'render entities'.<br>
 What makes detail brushes different from world brushes is that they 
don't participate in visibility calculation, which means they won't slow
 down hlvis.<br>
 A better description can be found here: <a href="http://developer.valvesoftware.com/wiki/Func_detail" target="_blank">http://developer.valvesoftware.com/wiki/Func_detail</a><br>
<br>
Differences between detail brushes, world brushes and func_walls:<br>
 Compared to world brushes, detail brushes don't block vis or slow down 
vis process, and don't chop faces from world brushes, and don't cause 
the 'Ambiguous leafnode content' warning.<br>
 Note that detail brushes cannot be used to seal a map, and must not be 
made of water or sky (but SKIP and CLIP can be used in func_details).<br>
 Compared to func_wall, func_detail don't consume engine's model 
precache slots (which is 512 max), and will give player mdl (and any 
other mdl) correct brightness when he steps over it.<br>
 In addition, there is an option that allows a func_detail to chop faces
 of world brushes in order to reduce face area and produce better 
lighting.<br>
 But unlike func_wall, the faces in func_detail will be cut if it 
happens to span across a splitting plane of the BSP structure generated 
from world brushes and func_details, thus increasing bsp file size and 
wpoly.<br>
<br>
Usage:<br>
 Convert any brushes, that are not parts of the basic structure of the 
map, to func_detail. They cannot be water brushes or sky brushes.<br>
 You can leave 'Detail level' to 1. For tiny objects, you might set it 
to 2, so that they won't chop the faces of other func_details.<br>
 For large shapes such as terrain and walls, you can set 'Lower its 
level to cut others' to no less than its detail level, so that they can 
chop adjacent world brushes like world brushes.<br>
 Before compiling the map, hide all entities and func_details, make sure
 there are no leaks and the structure is good enough for vis 
calculation.<br>
<br>
Further explanations:<br>
 To add the feature of detail brushes, I introduced a concept called 
'detail level', which is a number assigned to each brush, which can be 
0, 1, 2, 3,... .<br>
 --I will refer to all brushes that have the same detail level as a 'layer':<br>
   All world brushes are in the layer of detail level 0.<br>
   All brushes in a func_detail go to the layer corresponding to the func_detail's 'detail level' which is default to 1.<br>
   Brushes in brush entities such as func_wall are not in consideration here, because they are in seperated entities.<br>
 --In the CSG process:<br>
   Every layer will not be affected by any more detailed layers (with only one exception).<br>
   Every layer will be chopped by all less detailed layers. That is, if a
 brush in this layer is embedded into less detailed layers, then the 
embedded part will be chopped off.<br>
   Brushes in the same layer always chop each other.<br>
   The exception is, if you want a brush from a more detailed layer to 
chop the faces of a brush from a less detailed layer, you can either set
 the former's 'Lower its level to cut others' or the latter's 'Raise its
 level to get cut' to no less than the difference of their detail level.<br>
 --In the BSP process:<br>
   First, the surfaces of the layer of detail level 0 split the space 
into large leafs, which are also portal leafs that are used in vis 
calculation.<br>
   And the layer of detail level 0 is not allowed to have leaks, so detail brushes cannot be used to 'seal' a map.<br>
   Then the surfaces the layer of detail level 1 split every leaf into smaller leafs, but they no longer act as portal leafs.<br>
   Then does layer of detail level 2, 3,... .<br>
   Note that number of visleafs reported in the bsp statistics chart is the number of final leafs generated by all layers.<br>
 --In the VIS process:<br>
   The visibility data is calculated only according to portal leafs generated by the layer of detail level 0.<br>
   So, func_details will not increase the time of VIS process 
significantly. But they may have some impact on the VIS process, because
 when the BSP program is processing the layer of detail level 0, it has 
to also try to optimize the total number of faces, nodes and leafs.<br>
   After the calculation, the vis data between portal leafs is then 
converted to the vis data between final leafs. So adding func_details 
will increase the total size of vis data.<br>
<br>
Other notes:<br>
 The detail layers uses an advanced method to decide leafnode content, 
so detail brushes will not cause "Ambiguous leafnode contents" warnings 
and related problems.<br>
 Usually merely using detail level 0, 1 and 2 is enough. Using too many 
detail levels may make the BSP process inefficient and increase the bsp 
file size. For the same reason, 'Detail level of cliphulls' should 
always be 0 or 1 unless you are trying to solve some cliphull errors by 
adjusting this value.<br>
 Changing the 'Detail level of cliphulls' to 0 will reduce the number of
 clipnodes, but the cliphull of this func_detail will not use the new 
leafnode content method.<br>
<br>
<br>
<br>
When CLIP texture is used together with normal textures, which is not 
allowd before this update, the brush will act like a CLIP brush (block 
players, don't block bullets, grenades or flashlight) while its faces 
remain visible.<br>
Note that this brush will also not block light, unless it is tied to an entity with 'opaque' option on.<br>
A typical usage is wire mesh. Create a thin brush with wire mesh 
texture, and texture the thin side faces with CLIP. Then convert the 
brush to a func_wall with appropriate properties. You don't need to 
convert it to func_illusionary.<br>
This feature also makes it possible to let bullet pass through wire meshes which are parts of a moving entity.<br>
<br>
<br>
<br>
Add 'SOLIDHINT' texture which can help create better BSP structure for terrain and other complicated shapes.<br>
 The BSP process is to use planes to split the entire space into convex 
leafs. On each split, every face which spans across the splitting plane 
must be cut into two fragments by the plane.<br>
 In most cases, hlbsp can find a good splitting plane for each split, such that only a few faces are cut.<br>
 However, for some complicated shaped surfaces such as terrain and 
another chimney-like object in the sample map, you may find out that 
their faces are cut into a lot of fragments, when you view the map in 
BSPviewer or type gl_wireframe command in game.<br>
 This is because hlbsp chooses splitting plane only from the planes of 
existing faces on the surface, and all faces that are not on the surface
 of the object are ignored.<br>
 In the case of terrain, you can see that the surface only contains the 
triangle slopes, so it's hard for hlbsp to choose a good splitting plane
 from these slopes.<br>
<br>
SOLIDHINT makes it possibe to manually add extra faces for hlbsp to 
choose from, in order to help reduce face count and other counts.<br>
 For example, for the terrain created by 'Terrain Generator', the 
vertical planes on the grid lines cut no faces. So we can place 
SOLIDHINT faces along these planes.<br>
<br>
There are two ways of adding SOLIDHINT faces:<br>
 1. Like how you add a HINT face, create a brush with SOLIDHINT texture 
on one face and SKIP texture on other faces. The face with SOLIDHINT 
texture will become a SOLIDHINT face.<br>
 or 2. Replace the the texture of an invisible face of a normal brush to
 SOLIDHINT. Then a SOLIDHINT face will be copied from that face.<br>
<br>
The sample map uses the second way. In the sample map, a SOLIDHINT 
texture is applied to the shared face of two adjacent solid brushes. So 
it seems that the SOLIDHINT can "seperate" the two adjacent brushes and 
stop them from cutting each other.<br>
 If you want SOLIDHINT to "seperate" brushes that are part of func_details, make sure the SOLIDHINT is in the same detail level.<br>
<br>
Differences between SOLIDHINT and HINT:<br>
 1. HINT always cause the space to be cut into more but smaller leafs 
and increase the size of bsp file, while SOLIDHINT can reduce the number
 of cuts and decrease the size of bsp file. Placing more SOLIDHINT than 
needed will usually cause no side effect, except longer compile time in 
hlbsp stage.<br>
 2. There is no need to place HINT inside solid brushes because the 
purpose of HINT is better vis, while SOLIDHINT faces can be inside solid
 brushes.<br>
<br>
<br>
<br>
Add 'AllocBlock' amount report for '-chart'.<br>
The main problem one may face while building large maps is the 
'AllocBlock:full' error that occurs when the map is being loaded by the 
game engine.<br>
This new feature can tell the mapper how close to 'AllocBlock:full' error a map is.<br>
<br>
<br>
<br>
Change the condition of MAX_MAP_LEAFS warning.<br>
Now this warning only appears if the number of visleafs (leafs formed from world brushes) exceeds 8192.<br>
The bsp statistics chart can show the number of visleafs.<br>
I'm sure that having more than 8192 leafs will not cause any problems as long as the number of visleafs does not exceed 8192.<br>
I'm not sure whether having more than 8192 visleafs will make the game crush or cause any serious problem.<br>
<br>
Increase the limit of different textures from 512 to 4096.<br>
There are no evidence showing that 512 is an engine limit, and there 
seems to be no errors when I test a map with 2048 textures. So I decide 
to increase the limit.<br>
<br>
Replace the 'wad.cfg' system with a new way of configuring wad list, because the old way is very buggy and hard to understand.<br>
Now every wad config file only contains one set of wad files. The syntax is shown in the 'samplewadconfig.txt'.<br>
If you have more than one configuration, you should put them in different wad config files.<br>
To use a wad config file, you must add parameter '-wadcfgfile <path>' for hlcsg. The '<path>' can either be a full path, or be the relative path from map folder or tools folder.<br>
For example, the 'samplewadconfig.txt' is in the tools folder, so you can use '-wadcfgfie samplewadconfig.txt'.<br>
<br>
Fix the issue of water brushes leaking light.<br>
This only affects world brushes with liquid texture. This doesn't affect func_water.<br>
Now the underwater area will be totally dark unless you add light 
sources. (As for light sources, turning the water texture into texture 
light is a good idea)<br>
<br>
Fix the bug that the surface of func_water only emits texture light upwards and fails to emit texture light downwards.<br>
<br>
Remove the old weird and buggy way how hlbsp deals with HINT texture.<br>
Now HINT will probably work more efficiently than before.<br>
<br>
All 'aaatrigger' texture will automatically become invisible.<br>
<br>
Change hlrad's default '-gamma' from 0.5 to 0.55 and default '-texreflectgamma' from 2.5 to 2.2<br>
These values are more suitable for Half-Life's default gamma value for lighting and texture and Windows's gamma value.<br>
<br>
Change hlrad's default vismatrix method to sparse, because sparse is often a must for large maps.<br>
The parameters for each vismatrix methods have been changed to 
'-vismatrix sparse', '-vismatrix normal' and '-vismatrix off'. (But you 
can still use the old '-sparse' or '-nomatrix')<br>
<br>
Some other changes:<br>
Fix the broken '-nullfile' parameter.<br>
Opaque entities that are beyond sky brushes will not cast shadows.<br>
Increase the limit of visibility data size.<br>
The light_surface entity may automatically determine whether the texture
 light uses fast mode according to its brightness and the '-dlight' 
parameter.<br>
Remove hlrad's '-maxlight' parameter because it is useless and a little uncompatible with dynamic light styles.<br>
'-wadcfgfile', '-hullfile' and '-nullfile' will not require full path.<br>
<br>
The tools are compiled by vs2010. So their sizes are much bigger and they may run 10% slower than the older versions.
		</path></path></div>
		<!-- / message -->

		
		<!-- attachments -->
			<div style="padding:5px">

			

			

			

			
				<fieldset class="fieldset">
					<legend>Attached Files</legend>
					<table border="0" cellpadding="0" cellspacing="3">
					<tbody><tr>
	<td><img title="File Type: zip" class="inlineimg" src="showpost-Dateien/zip.gif" alt="File Type: zip" style="vertical-align: baseline;" border="0" height="16" width="16"></td>
	<td><a href="http://forums.svencoop.com/attachment.php?attachmentid=14731&amp;d=1321128868">zhlt vluzacn25.zip</a> (891.7 KB, 962 views)</td>
</tr><tr>
	<td><img title="File Type: zip" class="inlineimg" src="showpost-Dateien/zip.gif" alt="File Type: zip" style="vertical-align: baseline;" border="0" height="16" width="16"></td>
	<td><a href="http://forums.svencoop.com/attachment.php?attachmentid=14732&amp;d=1321128868">samplemap.zip</a> (105.1 KB, 94 views)</td>
</tr>
					</tbody></table>
				</fieldset>
			

			

			</div>
		<!-- / attachments -->
		

		
		

		

		

		
		<!-- edit note -->
			<div class="smallfont">
				<hr style="color:#51586A; background-color:#51586A" size="1">
				<em>
					
						Last edited by vluzacn; 12-11-2011 at <span class="time">02:20 PM</span>.
					
					
				</em>
			</div>
		<!-- / edit note -->
		

	</td>
</tr>
<tr>
	<td class="alt2" style="border-right: 1px solid rgb(81, 88, 106); border-width: 0px 1px 1px; border-style: none solid solid; border-color: -moz-use-text-color rgb(81, 88, 106) rgb(81, 88, 106); -moz-border-top-colors: none; -moz-border-right-colors: none; -moz-border-bottom-colors: none; -moz-border-left-colors: none; -moz-border-image: none;">
		
<img title="vluzacn is online now" class="inlineimg" src="showpost-Dateien/user_online.gif" alt="vluzacn is online now" border="0">

		
		
		
		
		&nbsp;
	</td>
	
	<td class="alt1" style="border-right: 1px solid rgb(81, 88, 106); border-width: 0px 1px 1px 0px; border-style: none solid solid none; border-color: -moz-use-text-color rgb(81, 88, 106) rgb(81, 88, 106) -moz-use-text-color; -moz-border-top-colors: none; -moz-border-right-colors: none; -moz-border-bottom-colors: none; -moz-border-left-colors: none; -moz-border-image: none;" align="right">
	
		<!-- controls -->
		
		
		
			<a href="http://forums.svencoop.com/newreply.php?do=newreply&amp;p=476471" rel="nofollow"><img title="Reply With Quote" src="showpost-Dateien/quote.gif" alt="Reply With Quote" border="0"></a>
		
		
		
		
		
		
		
			
		
		
		<!-- / controls -->
	</td>
</tr>
</tbody></table>


<!-- post 476471 popup menu -->
<div class="vbmenu_popup" id="postmenu_476471_menu" style="display:none">
	<table border="0" cellpadding="4" cellspacing="1">
	<tbody><tr>
		<td class="thead">vluzacn</td>
	</tr>
	
		<tr><td class="vbmenu_option"><a href="http://forums.svencoop.com/member.php?u=12810">View Public Profile</a></td></tr>
	
	
	
	
		<tr><td class="vbmenu_option"><a href="http://hi.baidu.com/vluzacn">Visit vluzacn's homepage!</a></td></tr>
	
	
		<tr><td class="vbmenu_option"><a href="http://forums.svencoop.com/search.php?do=finduser&amp;u=12810" rel="nofollow">Find More Posts by vluzacn</a></td></tr>
	
	
	
	</tbody></table>
</div>
<!-- / post 476471 popup menu -->


<!-- / post #476471 -->

<table class="tborder" style="border-top-width: 0px;" border="0" cellpadding="5" cellspacing="1" width="100%">
<tbody><tr>
	<td class="tfoot" align="center">
		<input class="button" value="Close this window" id="close_button" style="" type="button">
		&nbsp;
		<script type="text/javascript">
		<!--
		if (self.opener)
		{
			var close_button = fetch_object('close_button');
			close_button.style.display = '';
			close_button.onclick = function() { self.close(); };
		}
		//-->
		</script>
	</td>
</tr>
</tbody></table>

</form>


<!-- lightbox scripts -->
	<script type="text/javascript" src="showpost-Dateien/vbulletin_lightbox.js"></script>
	<script type="text/javascript">
	<!--
	vBulletin.register_control("vB_Lightbox_Container", "td_post_476471", 1);
	//-->
	</script>
<!-- / lightbox scripts -->


<script type="text/javascript">
<!--
	// Main vBulletin Javascript Initialization
	vBulletin_init();
//-->
</script>


</body></html>