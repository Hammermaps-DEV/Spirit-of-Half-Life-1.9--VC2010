======================================
======================================
 AUTO SEAMER BY: RYAN "NEMESIS" GREGG
======================================
======================================

=========================
Instalation Instructions:
=========================

Unzip the contents of autoseamer101.zip to any folder and
run it from there.

===========================
Program/Author Information:
===========================

---- General Program Information ----
Date                     : March 9th 2002
Author                   : Ryan "NEMESIS" Gregg
Title                    : Auto Seamer
Build                    : 1.0.1
Zip Filename             : autoseamer100.zip
EXE Filename             : Auto Seamer.exe
Email address            : nemesis232@hotmail.com
Home page /  Website     : http://nemesis.thewavelength.net/

---- Program Construction Information ----
Programing Time          : About 1.5 hours.
Lines                    : 590
Parimiters               : None.
Writen In                : Visual Basic 6.0 SP 5
Compiled To              : Native Code Optimized For Speed
Compile Machine          : P3 450, 224mb Ram
Compile time             : About 0:0:05.

==============================
Program Copyright-Permissions:
==============================

This program is Freeware.