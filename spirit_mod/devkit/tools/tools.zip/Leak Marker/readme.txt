	 ---------------------------------------------------------
	  LeakMarker 0.1		Martin "Saida" Gustafsson
	  http://saida.lava.nu		saida@lava.nu
	 ---------------------------------------------------------


 Contents
----------
 1. About LeakMarker
 2. Installation 
 3. Contact


 1. About LeakMarker
---------------------
 - This is a tool for showing
   leaks in a map made in WordCraft.

 - It has been tested with "WC 3.3" & "WC 3.4"
   Compilers tested: 
    * "Zoner's Halflife Tools 2.5.3"
    * "Standard Compile tools."

 - READ THE HOWTO.TXT     


 2. Installation
-----------------
 - Unzip, and run the program.


 3. Contacing
------------------------------  
 - Did you found a bug?
 - Don't you understand how this program work?
 Please write to:
 
 saida@lava.nu

